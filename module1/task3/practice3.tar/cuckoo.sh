#!/bin/bash
mkdir -p /tmp/run/
mkfifo /tmp/run/cuckoo.pid
echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> cuckoo.log

trap 'echo "$(date "+%Y-%m-%d %H:%M:%S") Shutdown!" >> cuckoo.log; rm -f /tmp/run/cuckoo.pid; exit 0' SIGTERM

while true; do
    read line < /tmp/run/cuckoo.pid
    if [[ "$line" =~ ^(.*)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
        name="${BASH_REMATCH[1]}"
        pid="${BASH_REMATCH[2]}"
        n=$((RANDOM % 9 + 2))
        echo "$(date '+%Y-%m-%d %H:%M:%S') ${name}[${pid}] $n" >> cuckoo.log
        echo "$n" > /tmp/run/cuckoo.pid
    fi
done
