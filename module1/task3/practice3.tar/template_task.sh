#!/bin/bash
name=$(basename "$0")
if [ "$name" == "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

log="report_${name}.log"
echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$log"

echo "${name}[$$]: how much time do I have?" > /tmp/run/cuckoo.pid
read n < /tmp/run/cuckoo.pid

sleep "$n"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $n секунд." >> "$log"
