#!/bin/bash
while read script; do
    if ! grep -q "$script" /proc/[0-9]*/cmdline 2>/dev/null; then
        nohup ./"$script" >/dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') $script запущен" >> observer.log
    fi
done < observer.conf
